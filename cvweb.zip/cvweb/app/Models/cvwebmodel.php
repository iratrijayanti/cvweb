<?php

namespace App\Models;

use CodeIgniter\Model;

class cvwebmodel extends Model
{
    public function About()
    {
        return $this->db->table("about")
            ->get()
            ->getResultArray();
    }

    public function Counts()
    {
        return $this->db->table("counts")
            ->get()
            ->getResultArray();
    }

    public function Skills()
    {
        return $this->db->table("skills")
            ->get()
            ->getResultArray();
    }
}
