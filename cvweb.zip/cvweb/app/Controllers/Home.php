<?php

namespace App\Controllers;

use App\Models\cvwebmodel;

class Home extends BaseController
{
    protected $datacvira;
    public function __construct()
    {
        $this->datacvira = new cvwebmodel;
    }

    public function index(): string
    {

        // About
        $abouts = new cvwebmodel();
        $about = $abouts->About();

        // Counts
        $counts = new cvwebmodel();
        $count = $counts->Counts();

        // Counts
         $skills = new cvwebmodel();
         $skill = $skills->Skills();

        $data = [
            'title_about' => 'About Me',
            'abouts' => $about,
            'counts' => $count,
            'skills' => $skill
        ];
        return view('index', $data);
    }
}
